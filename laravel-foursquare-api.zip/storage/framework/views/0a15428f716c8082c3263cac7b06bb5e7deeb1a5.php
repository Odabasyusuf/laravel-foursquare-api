
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Harita</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">

                <iframe width="425" height="350" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://www.openstreetmap.org/export/embed.html?bbox=33.77150%2C41.38111&amp;layer=mapnik&amp;marker=41.381107091805255%2C33.77150101408415" style="border: 1px solid black"></iframe><br/><small><a href="https://www.openstreetmap.org/?mlat=41.38111&amp;mlon=33.77150#map=18/41.38111/33.77150">Daha Büyük Haritayı Göster</a></small>

            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\laravel-foursquare-api\resources\views/mapPopup.blade.php ENDPATH**/ ?>