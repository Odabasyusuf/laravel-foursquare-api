<div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6 col-xl-5">
                <div class="card mb-0">

                    
                    <form action="<?php echo e(route('arama')); ?>" method="POST" style="margin-bottom: 0px;">
                        <?php echo csrf_field(); ?>
                    <div class="search"></i> <input type="text" class="form-control" name="sehirAra"
                                                                            placeholder="Şehir Ara" autocomplete="off">
                        <button class="btn btn-primary">Ara</button>
                    </div>
                    </form>
                    
                </div>
            </div>
        </div>
</div>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel-foursquare-api\resources\views/index.blade.php ENDPATH**/ ?>